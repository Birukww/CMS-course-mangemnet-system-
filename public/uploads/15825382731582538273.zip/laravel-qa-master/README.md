# laravel-qa
Question and Answer Application build in Laravel 6
